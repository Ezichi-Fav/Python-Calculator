

# user input
firstnum = float(input("Enter first number: "))
secondnum = float(input("Enter second number: "))

# operation selectors
print("Operation: +, -, %, *, /")
userinput = input("Select operations: ")

# conditions
if userinput == "+":
    print(firstnum, "+", secondnum, "=", firstnum+secondnum)

elif userinput == "-":
    print(firstnum, "-", secondnum, "=", firstnum-secondnum)

elif userinput == "%":
    try:
     firstnum==secondnum == 0
    print ("zero is invalid for this case ")
    except:
    firstnum>0
    secondnum>0
    print(firstnum, "%", secondnum, "=", firstnum%secondnum)
elif userinput == "*":
    print(firstnum, "*", secondnum, "=", firstnum*secondnum)

elif userinput == "/":
    print(firstnum, "/", secondnum, "=", firstnum/secondnum)

else:
    print("The operator you have chosen is invalid")



    #Hi Please I am struggling with exception handling, I tried to implement it in another task but it did not work too. I ould appreciate a feedback on how I am getting rong. Thank you.